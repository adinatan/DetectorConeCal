function [qphi,iq,sourceFiles] = read_pilatus_qphi(outDir,outputIndex)
%READ_PILATUS_QPHI Read one saved DeltaI(q,phi) output window.
arguments
    outDir (1,1) string
    outputIndex (1,1) double {mustBeInteger,mustBePositive}
end
M=load(fullfile(outDir,'manifest.mat'),'manifest');
m=M.manifest;
assert(outputIndex<=m.nOutput,'pilatus:OutputIndex','Output index exceeds nOutput.');
c=find(outputIndex>=m.firstOutput & outputIndex<=m.lastOutput,1,'first');
assert(~isempty(c),'pilatus:ChunkLookup','Could not locate output chunk.');
file=fullfile(outDir,m.chunkNames(c));
assert(isfile(file),'pilatus:MissingChunk','Missing q-phi chunk: %s',file);
S=load(file,'deltaIqChunk','deltaQPhi','chunkMeta');
assert(isfield(S,'deltaQPhi'),'pilatus:NoQPhi','This run did not save DeltaI(q,phi).');
k=outputIndex-S.chunkMeta.firstOutput+1;
qphi=S.deltaQPhi(:,:,k);
iq=S.deltaIqChunk(:,k);
firstInput=2*m.window*(outputIndex-1)+1;
lastInput=2*m.window*outputIndex;
sourceFiles=m.files(firstInput:lastInput);
end
