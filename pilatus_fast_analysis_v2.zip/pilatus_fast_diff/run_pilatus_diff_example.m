% EDIT THESE PATHS. Input must contain ONE numbered acquisition series.
inDir  = "D:\pilatus\run001";
outDir = "E:\analysis\run001_w3";  % New or empty folder, not the input folder.

% 1 means I2-I1, I4-I3, ...
% 3 means (I2+I4+I6-I1-I3-I5)/3, then (I8+I10+I12-I7-I9-I11)/3, ...
window = 3;

[files,frameIDs,fileBytes] = pilatus_filelist(inDir,"*.tif");
fprintf('Input bytes: %.3f TB\n',sum(fileBytes)/1e12);
fprintf('First two filename IDs: %d and %d\n',frameIDs(1),frameIDs(2));
% Check that files(2) is the state to ADD and files(1) the state to SUBTRACT.

report = pilatus_diff(files,outDir,window, ...
    Workers=2, ...             % Benchmark 1, 2, and 4 on the actual storage.
    Reader="tiff", ...        % Compare "imread" with the benchmark helper.
    Format="mat", ...         % Uncompressed MAT chunks. Alternative: "raw".
    ChunkFrames=64, ...        % Outputs per file, NOT the averaging window.
    Accumulator="double", ... % Preserve precision before subtracting counts.
    OutputClass="single");    % Use "double" to avoid final float32 rounding.

[D1,inputsForD1] = read_pilatus_diff(outDir,1);
disp(inputsForD1)
imagesc(D1); axis image; colorbar
