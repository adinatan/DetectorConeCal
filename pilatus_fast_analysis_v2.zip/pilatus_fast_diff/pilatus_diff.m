function report = pilatus_diff(files, outDir, window, opts)
%PILATUS_DIFF Stream non-overlapping even-minus-odd TIFF window averages.
% report = pilatus_diff(files,outDir,window,Workers=2,Format="mat")
%
% Output g = sum_{j=1:window}(I_{2*window*(g-1)+2*j}
%                            - I_{2*window*(g-1)+2*j-1})/window.
% Frame numbers in this formula are POSITIONS IN files, not filename numbers.
% files must be an explicitly ordered vector for ONE acquisition/condition.
% Use pilatus_filelist to sort a single numbered series and reject gaps.
%
% Defaults: serial CPU, Tiff reader, double arithmetic, single output,
% 64 output frames per uncompressed MAT file. Format="raw" writes little-
% endian column-major binary chunks. read_pilatus_diff reads either format.
% Negative input pixels are invalid by default. A pixel invalid in ANY input
% of a window becomes NaN in that output. Zero counts remain valid.
%
% Options:
%   Workers       1 (serial), 2, or 4 are recommended benchmark candidates.
%   Reader        "tiff" (default), "imread".
%   Format        "mat" (default), "raw".
%   ChunkFrames   Output images per chunk, default 64. Independent of window.
%   Accumulator   "double" (default), "single" (check precision first).
%   OutputClass   "single" (default), "double".
%   BadMask       Logical H-by-W mask, TRUE = invalid. Default [].
%   MaskNegative  true by default, suitable for raw photon-count images.
%   BadValues     Explicit invalid raw values, e.g. [4294967295 4294967294]
%                 ONLY after verifying a uint32 sentinel convention.
%   TailPolicy    "drop" (warn and record trailing files), or "error".
%   ShowProgress  true by default.
%
% Requires MATLAB; Workers>1 also requires Parallel Computing Toolbox.
% Only single-page, monochrome TIFF acquisitions are intended. Reader reads
% page 1. Per-frame normalization is NOT performed. Source TIFFs are untouched.
% outDir must be new or empty. No automatic resume after interruption.

arguments
    files (:,1) string
    outDir (1,1) string
    window (1,1) double {mustBeInteger,mustBePositive}
    opts.Workers (1,1) double {mustBeInteger,mustBePositive} = 1
    opts.Reader (1,1) string {mustBeMember(opts.Reader,["tiff","imread"])} = "tiff"
    opts.Format (1,1) string {mustBeMember(opts.Format,["mat","raw"])} = "mat"
    opts.ChunkFrames (1,1) double {mustBeInteger,mustBePositive} = 64
    opts.Accumulator (1,1) string {mustBeMember(opts.Accumulator,["double","single"])} = "double"
    opts.OutputClass (1,1) string {mustBeMember(opts.OutputClass,["single","double"])} = "single"
    opts.BadMask logical = []
    opts.MaskNegative (1,1) logical = true
    opts.BadValues double = []
    opts.TailPolicy (1,1) string {mustBeMember(opts.TailPolicy,["drop","error"])} = "drop"
    opts.ShowProgress (1,1) logical = true
end

assert(isempty(opts.BadValues) || (isvector(opts.BadValues) && all(isfinite(opts.BadValues))), ...
    'pilatus:BadValues','BadValues must be a finite numeric vector.');
nInput = numel(files);
nOutput = floor(nInput/(2*window));
nUsed = nOutput*2*window;
assert(nOutput>0,'pilatus:TooFewFiles','Need at least 2*window input files.');
assert(all(strlength(files)>0),'pilatus:EmptyPath','Empty input filename.');
assert(numel(unique(files))==nInput,'pilatus:DuplicatePath','Duplicate input filenames.');
if nUsed<nInput
    if opts.TailPolicy=="error"
        error('pilatus:IncompleteWindow','%d trailing files do not fill a window.',nInput-nUsed);
    end
    warning('pilatus:DroppedTail', ...
        '%d trailing files omitted and recorded in manifest.ignoredFiles.',nInput-nUsed);
end

% One initial probe, then each USED input is read once by the processing loop.
probe = pilatus_read_tiff(files(1),opts.Reader);
assert(ismatrix(probe) && isnumeric(probe),'pilatus:NotMonochrome', ...
    'Expected a numeric 2-D monochrome TIFF.');
imageSize = size(probe);
nativeClass = class(probe);
assert(~ismember(string(nativeClass),["int64","uint64"]),'pilatus:UnsupportedType', ...
    '64-bit integer input is not supported by this floating-point pipeline.');
if ~isempty(opts.BadMask)
    assert(isequal(size(opts.BadMask),imageSize),'pilatus:MaskSize','BadMask size mismatch.');
end
clear probe

bytesPerValue = 4+4*(opts.OutputClass=="double");
chunkBytes = prod(imageSize)*min(opts.ChunkFrames,nOutput)*bytesPerValue;
if opts.Format=="mat" && chunkBytes>1.8e9
    error('pilatus:ChunkTooLarge', ...
        'Reduce ChunkFrames: keep each v7 MAT data array below 1.8 GB.');
end
if chunkBytes*opts.Workers>8e9
    warning('pilatus:MemoryBudget', ...
        'Output buffers alone exceed 8 GB. Reduce ChunkFrames on a 32 GB machine.');
end

% Never overwrite previous results or source files.
if isfolder(outDir)
    listing = dir(outDir);
    listing = listing(~ismember({listing.name},{'.','..'}));
    assert(isempty(listing),'pilatus:OutputNotEmpty','Output folder must be new or empty.');
else
    [ok,msg] = mkdir(outDir);
    assert(ok,'pilatus:CreateDirectory','Cannot create output folder: %s',msg);
end

nChunks = ceil(nOutput/opts.ChunkFrames);
firstOutput = (0:nChunks-1)'*opts.ChunkFrames+1;
lastOutput = min(firstOutput+opts.ChunkFrames-1,nOutput);
if opts.Format=="mat", ext=".mat"; else, ext=".bin"; end
chunkNames = compose("diff_%06d",(1:nChunks)')+ext;
% Slice filenames by chunk: never return image arrays to the client.
chunkInputs = cell(nChunks,1);
for c=1:nChunks
    firstInput = 2*window*(firstOutput(c)-1)+1;
    lastInput = 2*window*lastOutput(c);
    chunkInputs{c} = files(firstInput:lastInput);
end

manifest.version = 1;
manifest.complete = false;
manifest.files = files(1:nUsed);
manifest.ignoredFiles = files(nUsed+1:end);
manifest.window = window;
manifest.nOutput = nOutput;
manifest.imageSize = imageSize;
manifest.nativeClass = nativeClass;
manifest.options = opts;
manifest.chunkNames = chunkNames;
manifest.firstOutput = firstOutput;
manifest.lastOutput = lastOutput;
manifest.rawByteOrder = 'ieee-le';
manifest.rawArrayOrder = 'MATLAB column-major, [height width frame]';
manifest.definition = 'mean(even positions)-mean(odd positions), non-overlapping';
save(fullfile(outDir,'manifest.mat'),'manifest','-v7','-nocompression');

poolSeconds = 0;
if opts.Workers>1
    tPool = tic;
    p = gcp('nocreate');
    if isempty(p)
        p = parpool('Processes',opts.Workers);
    end
    assert(~isa(p,'parallel.ThreadPool'),'pilatus:ThreadPool', ...
        'TIFF I/O requires processes. Close the thread pool with delete(gcp(''nocreate'')).');
    assert(p.NumWorkers>=opts.Workers,'pilatus:SmallPool', ...
        'Existing pool is too small. Close it and rerun, or reduce Workers.');
    poolSeconds = toc(tPool);
end

if opts.ShowProgress
    fprintf('%d input files -> %d differences, window=%d, %d chunks.\n', ...
        nUsed,nOutput,window,nChunks);
    fprintf('Reader=%s, workers=%d, arithmetic=%s, output=%s/%s.\n', ...
        opts.Reader,opts.Workers,opts.Accumulator,opts.Format,opts.OutputClass);
    fprintf('First pair: [%s] minus [%s]\n',files(2),files(1));
end
chunkSeconds = zeros(nChunks,1);
tRun = tic;
if opts.Workers==1
    for c=1:nChunks
        chunkSeconds(c) = processChunk(chunkInputs{c},fullfile(outDir,chunkNames(c)), ...
            window,imageSize,nativeClass,opts);
        if opts.ShowProgress && (mod(c,max(1,ceil(nChunks/20)))==0 || c==nChunks)
            fprintf('Completed %d/%d chunks.\n',c,nChunks);
        end
    end
else
    % A worker owns the entire read -> compute -> save operation for its chunk.
    % parfor's worker limit lets a larger existing process pool be reused.
    nWorkers = opts.Workers;
    parfor (c=1:nChunks,nWorkers)
        chunkSeconds(c) = processChunk(chunkInputs{c},fullfile(outDir,chunkNames(c)), ...
            window,imageSize,nativeClass,opts);
        if opts.ShowProgress && (mod(c,max(1,ceil(nChunks/20)))==0 || c==nChunks)
            fprintf('Finished chunk %d of %d (completion order may vary).\n',c,nChunks);
        end
    end
end
report.processingSeconds = toc(tRun);
report.poolSetupSeconds = poolSeconds;
report.nInputUsed = nUsed;
report.nIgnored = nInput-nUsed;
report.nOutput = nOutput;
report.nChunks = nChunks;
report.inputFramesPerSecond = nUsed/report.processingSeconds;
report.outputPayloadBytes = prod(imageSize)*nOutput*bytesPerValue;
report.chunkSeconds = chunkSeconds;
report.outputDirectory = outDir;
% Processing time includes TIFF reading, arithmetic, chunk writing/closing and
% dispatch, but excludes initial probe, manifest saves and process-pool setup.
% It is NOT a disk durability benchmark: OS/controller caches may still flush.
manifest.complete = true;
manifest.report = report;
save(fullfile(outDir,'manifest.mat'),'manifest','-v7','-nocompression');
if opts.ShowProgress
    fprintf('Done: %.3f s, %.2f input images/s. Pool setup: %.3f s.\n', ...
        report.processingSeconds,report.inputFramesPerSecond,poolSeconds);
end
end

function seconds = processChunk(files,outfile,window,imageSize,nativeClass,opts)
t = tic;
n = numel(files)/(2*window);
D = zeros([imageSize n],char(opts.OutputClass));
for g=1:n
    S = zeros(imageSize,char(opts.Accumulator));
    base = 2*window*(g-1);
    for j=1:window
        A = prepare(pilatus_read_tiff(files(base+2*j-1),opts.Reader), ...
            imageSize,nativeClass,opts);
        B = prepare(pilatus_read_tiff(files(base+2*j),opts.Reader), ...
            imageSize,nativeClass,opts);
        % Cast BEFORE subtraction, never subtract uint32 or sum int32 counts.
        % Subtract pairs first, rather than subtract two large final means.
        S = S+(B-A);
    end
    X = S/cast(window,char(opts.Accumulator));
    if ~isempty(opts.BadMask), X(opts.BadMask)=NaN; end
    D(:,:,g) = cast(X,char(opts.OutputClass));
end
clear A B S X

% Each chunk has a unique filename, so workers never write the same file.
% A temporary name prevents an interrupted write looking like a final chunk.
if opts.Format=="mat"
    tmp = outfile+".partial.mat";
    save(tmp,'D','-v7','-nocompression');
else
    tmp = outfile+".partial";
    [fid,msg] = fopen(tmp,'w','ieee-le');
    assert(fid~=-1,'pilatus:OpenOutput','Cannot open output: %s',msg);
    try
        written = fwrite(fid,D,char(opts.OutputClass));
        assert(written==numel(D),'pilatus:ShortWrite','Incomplete binary write.');
    catch err
        fclose(fid);
        rethrow(err);
    end
    status = fclose(fid);
    assert(status==0,'pilatus:CloseOutput','Failed to close output file.');
end
[ok,msg] = movefile(tmp,outfile);
assert(ok,'pilatus:RenameOutput','Cannot finalize output chunk: %s',msg);
seconds = toc(t);
end

function x = prepare(raw,imageSize,nativeClass,opts)
assert(isequal(size(raw),imageSize),'pilatus:ImageSize','Image dimensions changed within a run.');
assert(strcmp(class(raw),nativeClass),'pilatus:ImageType','Image datatype changed within a run.');
x = cast(raw,char(opts.Accumulator));
if opts.MaskNegative, x(raw<0)=NaN; end
for value=reshape(opts.BadValues,1,[])
    x(raw==value)=NaN;  % Compare BEFORE a possibly lossy single conversion.
end
if isfloat(raw), x(~isfinite(raw))=NaN; end
end
