function selftest_pilatus_diff(runParallel)
%SELFTEST_PILATUS_DIFF Tiny synthetic correctness tests, run locally in MATLAB.
% selftest_pilatus_diff          % serial tests, no real data required
% selftest_pilatus_diff(true)    % also test two process workers
% Leaves no source or output files after a successful test or caught error.
arguments
    runParallel (1,1) logical = false
end
root = string(tempname);
mkdir(root);
cleanup = onCleanup(@() rmdir(root,'s')); %#ok<NASGU>
in = fullfile(root,'inputs'); mkdir(in);
H=9; W=11; N=12;
rngState = rng; rngCleanup=onCleanup(@() rng(rngState)); %#ok<NASGU>
rng(27);
images = randi([0 2000],[H W N],'int32');
images(1,1,:) = -1;             % persistent invalid pixel
images(2,2,4) = -2;             % one-frame invalid pixel
images(3,3,1) = int32(2^24);    % catches casting to single BEFORE subtraction
images(3,3,2) = int32(2^24+1);
images(4,4,1) = 100; images(4,4,2) = 1; % negative difference must survive
for k=1:N
    file = fullfile(in,compose("image_%d.tif",k)); % intentionally NOT zero-padded
    writeSynthetic(file,images(:,:,k));
end
[files,ids] = pilatus_filelist(in);
assert(isequal(ids,(1:N)'));    % ensures 1,2,...,10 rather than 1,10,11,2
workersList=1;
if runParallel, workersList=[1 2]; end
for workers=workersList
    for window=[1 3]
        for format=["mat" "raw"]
            out=fullfile(root,compose("out_%d_%d_%s",workers,window,format));
            r=pilatus_diff(files,out,window,Workers=workers,Format=format, ...
                ChunkFrames=2,ShowProgress=false);
            assert(r.nOutput==N/(2*window));
            for g=1:r.nOutput
                i=(g-1)*2*window+(1:2*window);
                a=double(images(:,:,i)); a(a<0)=NaN;
                expected=single((sum(a(:,:,2:2:end),3)-sum(a(:,:,1:2:end),3))/window);
                actual=read_pilatus_diff(out,g);
                assert(isequaln(actual,expected),'Synthetic arithmetic/output test failed.');
                if window==1 && g==1
                    assert(actual(3,3)==1 && actual(4,4)==-99);
                end
            end
        end
    end
end
% Verify gap protection; removing a file must not silently flip all pairings.
delete(files(5));
failed=false;
try, pilatus_filelist(in); catch err, failed=strcmp(err.identifier,'pilatus:SequenceGap'); end
assert(failed,'Missing-file validation did not trigger.');
fprintf('Synthetic tests passed: ordering, negative differences, invalid pixels,\n');
fprintf('precision before subtraction, windows 1/3, MAT/raw roundtrips, and missing-file rejection.\n');
end

function writeSynthetic(file,A)
t=Tiff(char(file),'w');
try
    tag.ImageLength=size(A,1); tag.ImageWidth=size(A,2);
    tag.Photometric=Tiff.Photometric.MinIsBlack;
    tag.BitsPerSample=32; tag.SamplesPerPixel=1;
    tag.SampleFormat=Tiff.SampleFormat.Int;
    tag.PlanarConfiguration=Tiff.PlanarConfiguration.Chunky;
    tag.Compression=Tiff.Compression.None;
    tag.RowsPerStrip=size(A,1);
    setTag(t,tag); write(t,A);
catch err
    close(t); rethrow(err);
end
close(t);
end
