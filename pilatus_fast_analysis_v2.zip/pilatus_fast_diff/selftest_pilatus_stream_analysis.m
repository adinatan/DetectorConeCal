function selftest_pilatus_stream_analysis(runParallel)
%SELFTEST_PILATUS_STREAM_ANALYSIS Synthetic normalization/binning correctness test.
arguments
    runParallel (1,1) logical = false
end
root=string(tempname); mkdir(root);
cleanup=onCleanup(@() rmdir(root,'s')); %#ok<NASGU>
in=fullfile(root,'inputs'); mkdir(in);
H=4; W=6; N=8;
qMap=repmat(1:W,H,1);
phiMap=repmat((1:H)',1,W);
geometry=ones(H,W); polarization=ones(H,W);
badMask=false(H,W); badMask(4,6)=true;
normMask=false(H,W); normMask(1,:)=true;
normMask(badMask)=false;
nNorm=nnz(normMask);
scales=(1:N)'+3;
base=10*ones(H,W);
signal=zeros(H,W); signal(2,3)=5; signal(3,4)=-2;
images=zeros(H,W,N,'int32');
for k=1:N
    target=base;
    if mod(k,2)==0, target=target+signal; end
    images(:,:,k)=int32(scales(k)*target);
    file=fullfile(in,compose("image_%d.tif",k));
    writeSynthetic(file,images(:,:,k));
end
[files,ids]=pilatus_filelist(in); assert(isequal(ids,(1:N)'));
workers=1; if runParallel, workers=2; end
out=fullfile(root,'out');
qEdges=0.5:1:(W+0.5); phiEdges=0.5:1:(H+0.5);
r=pilatus_stream_analysis(files,out,2,Workers=workers,ChunkFrames=1, ...
    ShowProgress=false,BadMask=badMask,NormMask=normMask,NormReference=10*nNorm, ...
    QMap=qMap,PhiMap=phiMap,Geometry=geometry,Polarization=polarization, ...
    QEdges=qEdges,PhiEdges=phiEdges,SaveQPhi=true,SaveDiff2D=false);
assert(r.nOutput==2);
S=load(fullfile(out,'summary.mat'),'summary'); R=S.summary;
expectedNorm=scales*(10*nNorm);
assert(max(abs(R.normalization.value-expectedNorm))<1e-9);
expectedDiff=signal; expectedDiff(badMask)=NaN;
assert(max(abs(R.avgDiff2D(~badMask)-expectedDiff(~badMask)),[],'all')<1e-6);
% q-phi bins correspond one-to-one with detector pixels: [q,phi] = transpose(image).
[Q,iq]=read_pilatus_qphi(out,1); %#ok<ASGLU>
QT=Q';
assert(max(abs(QT(~badMask)-expectedDiff(~badMask)),[],'all')<1e-6);
% sumAll2D is the sum of all normalized source images.
expectedSum=N*base + (N/2)*signal; expectedSum(badMask)=NaN;
assert(max(abs(R.sumAll2D(~badMask)-expectedSum(~badMask)),[],'all')<1e-6);
assert(size(R.deltaIq,2)==2 && numel(R.sumAllIq)==W);
fprintf('pilatus_stream_analysis synthetic test passed.\n');
end

function writeSynthetic(file,A)
t=Tiff(char(file),'w');
try
    tag.ImageLength=size(A,1); tag.ImageWidth=size(A,2);
    tag.Photometric=Tiff.Photometric.MinIsBlack;
    tag.BitsPerSample=32; tag.SamplesPerPixel=1;
    tag.SampleFormat=Tiff.SampleFormat.Int;
    tag.PlanarConfiguration=Tiff.PlanarConfiguration.Chunky;
    tag.Compression=Tiff.Compression.None;
    tag.RowsPerStrip=size(A,1);
    setTag(t,tag); write(t,A);
catch err
    close(t); rethrow(err);
end
close(t);
end
