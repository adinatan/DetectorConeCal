function report = pilatus_stream_analysis(files,outDir,window,opts)
%PILATUS_STREAM_ANALYSIS Stream normalized PILATUS TIFF analysis in one pass.
%
% Core sequence for every source frame:
%   raw TIFF -> static/dynamic mask -> normalization scalar from NormMask
%            -> normalized detector image
%
% For every non-overlapping output window:
%   D = mean_j( normalized_even_j - normalized_odd_j )
%   D -> geometry/polarization correction -> radial DeltaI(q)
%                                      \--> DeltaI(q,phi)
%
% In the same TIFF pass the function also accumulates:
%   * normalization.value(frame): raw sum in NormMask
%   * sumAll2D: sum of ALL NORMALIZED masked source images (not differences)
%   * sumAllRaw2D: raw-count sum, provided as an extra diagnostic
%   * avgDiff2D: mean of all output 2-D window differences
%
% At the end it generates I(q) and I(q,phi) for sumAll2D and avgDiff2D.
% DeltaI(q) for all outputs is stored in summary.mat. DeltaI(q,phi) is
% optionally stored in chunk files to avoid keeping a huge 3-D array in RAM.
%
% NORMALIZATION
%   normalization.value(k) = sum(raw pixels in NormMask after invalid pixels
%                                and BadMask are excluded)
%   normalized frame = raw frame * NormReference / normalization.value(k)
%   NormReference=1 gives intensity per normalization-count. Set it to a
%   representative monitor sum if you want approximately count-like units.
%
% CORRECTIONS
%   By default corrected intensity = image ./ (Geometry .* Polarization).
%   Set CorrectionMode="multiply" if your supplied arrays are already inverse
%   correction multipliers, or "none" to bin without these corrections.
%
% BINNING
%   I(q) and I(q,phi) are PIXEL MEANS within each bin, after correction.
%   QMap and PhiMap are detector-sized coordinate maps. QEdges/PhiEdges may be
%   supplied explicitly; otherwise linear edges are made from the map ranges.
%
% INPUT ORDER / WINDOW
%   window=1: I2-I1, I4-I3, ... after per-frame normalization.
%   window=3: ((I2-I1)+(I4-I3)+(I6-I5))/3, then next six inputs, ...
%   Positions refer to the ordered files vector, not filename parity.
%
% The function uses process workers, never a thread pool. Each worker owns a
% contiguous set of output chunks, so source TIFFs are read exactly once while
% only one detector-sized summary per worker is returned to the client.
%
% Required name-value inputs:
%   NormMask     logical detector-size mask, TRUE = use for normalization sum
%   QMap         detector-size q value for every pixel
%
% Important options:
%   PhiMap       detector-size phi map. Required when SaveQPhi=true.
%   Geometry     detector-size geometric attenuation/correction factor.
%   Polarization detector-size polarization attenuation/correction factor.
%   BadMask      detector-size logical mask, TRUE = invalid BEFORE difference.
%   QEdges       explicit q bin edges. Default: NQBins linear bins.
%   PhiEdges     explicit phi bin edges. Default: NPhiBins linear bins.
%   SaveQPhi     default true. Chunk DeltaI(q,phi) to disk.
%   SaveDiff2D   default false. Saving detector differences can be enormous.
%   ChunkFrames  output windows per q-phi/difference chunk, default 64.
%
% summary.mat contains a struct named summary. qphi_*.mat contains the optional
% per-window q-phi maps and/or detector differences.

arguments
    files (:,1) string
    outDir (1,1) string
    window (1,1) double {mustBeInteger,mustBePositive}
    opts.Workers (1,1) double {mustBeInteger,mustBePositive} = 1
    opts.Reader (1,1) string {mustBeMember(opts.Reader,["tiff","imread"])} = "tiff"
    opts.ChunkFrames (1,1) double {mustBeInteger,mustBePositive} = 64
    opts.Accumulator (1,1) string {mustBeMember(opts.Accumulator,["double","single"])} = "double"
    opts.OutputClass (1,1) string {mustBeMember(opts.OutputClass,["single","double"])} = "single"
    opts.BadMask logical = []
    opts.MaskNegative (1,1) logical = true
    opts.BadValues double = []
    opts.NormMask logical = []
    opts.NormReference (1,1) double {mustBeFinite,mustBePositive} = 1
    opts.QMap = []
    opts.PhiMap = []
    opts.Geometry = []
    opts.Polarization = []
    opts.CorrectionMode (1,1) string {mustBeMember(opts.CorrectionMode,["divide","multiply","none"])} = "divide"
    opts.QEdges double = []
    opts.NQBins (1,1) double {mustBeInteger,mustBePositive} = 1000
    opts.PhiEdges double = []
    opts.NPhiBins (1,1) double {mustBeInteger,mustBePositive} = 360
    opts.SaveQPhi (1,1) logical = true
    opts.SaveDiff2D (1,1) logical = false
    opts.SaveRawSum (1,1) logical = true
    opts.TailPolicy (1,1) string {mustBeMember(opts.TailPolicy,["drop","error"])} = "drop"
    opts.ShowProgress (1,1) logical = true
end

assert(isempty(opts.BadValues) || (isvector(opts.BadValues) && all(isfinite(opts.BadValues))), ...
    'pilatus:BadValues','BadValues must be a finite numeric vector.');
assert(~isempty(opts.NormMask),'pilatus:NormMaskRequired','NormMask is required.');
assert(~isempty(opts.QMap) && isnumeric(opts.QMap),'pilatus:QMapRequired','Numeric QMap is required.');
if opts.SaveQPhi
    assert(~isempty(opts.PhiMap) && isnumeric(opts.PhiMap), ...
        'pilatus:PhiMapRequired','PhiMap is required when SaveQPhi=true.');
end

nInput = numel(files);
nOutput = floor(nInput/(2*window));
nUsed = nOutput*2*window;
assert(nOutput>0,'pilatus:TooFewFiles','Need at least 2*window input files.');
assert(all(strlength(files)>0),'pilatus:EmptyPath','Empty input filename.');
assert(numel(unique(files))==nInput,'pilatus:DuplicatePath','Duplicate input filenames.');
if nUsed<nInput
    if opts.TailPolicy=="error"
        error('pilatus:IncompleteWindow','%d trailing files do not fill a window.',nInput-nUsed);
    end
    warning('pilatus:DroppedTail', ...
        '%d trailing files omitted and recorded in manifest.ignoredFiles.',nInput-nUsed);
end

% Probe once for detector dimensions/datatype. The processing pass still reads
% every USED source image exactly once.
probe = pilatus_read_tiff(files(1),opts.Reader);
assert(ismatrix(probe) && isnumeric(probe),'pilatus:NotMonochrome', ...
    'Expected a numeric 2-D monochrome TIFF.');
imageSize = size(probe);
nativeClass = class(probe);
clear probe
assert(~ismember(string(nativeClass),["int64","uint64"]),'pilatus:UnsupportedType', ...
    '64-bit integer input is not supported by this floating-point pipeline.');

validateDetectorArray(opts.NormMask,imageSize,'NormMask');
if ~isempty(opts.BadMask), validateDetectorArray(opts.BadMask,imageSize,'BadMask'); end
validateDetectorArray(opts.QMap,imageSize,'QMap');
if ~isempty(opts.PhiMap), validateDetectorArray(opts.PhiMap,imageSize,'PhiMap'); end
if ~isempty(opts.Geometry), validateDetectorArray(opts.Geometry,imageSize,'Geometry'); end
if ~isempty(opts.Polarization), validateDetectorArray(opts.Polarization,imageSize,'Polarization'); end

badMask = false(imageSize);
if ~isempty(opts.BadMask), badMask = opts.BadMask; end
normBaseMask = opts.NormMask & ~badMask;
assert(any(normBaseMask,'all'),'pilatus:EmptyNormMask', ...
    'NormMask has no usable pixels after applying BadMask.');

% Precompute all reciprocal-space bin membership and correction multipliers.
binning = buildBinning(opts.QMap,opts.PhiMap,badMask,opts);

% Protect against accidentally making enormous per-chunk q-phi/detector files.
bytesOut = 4 + 4*(opts.OutputClass=="double");
maxChunkOut = min(opts.ChunkFrames,nOutput);
chunkPayload = numel(binning.qCenters)*maxChunkOut*bytesOut;
if opts.SaveQPhi
    chunkPayload = chunkPayload + numel(binning.qCenters)*numel(binning.phiCenters)*maxChunkOut*bytesOut;
end
if opts.SaveDiff2D
    chunkPayload = chunkPayload + prod(imageSize)*maxChunkOut*bytesOut;
end
if chunkPayload>1.6e9
    error('pilatus:ChunkTooLarge', ...
        'Reduce ChunkFrames: estimated chunk payload is %.2f GB.',chunkPayload/1e9);
end

% Output directory must be new or empty, mirroring pilatus_diff behavior.
if isfolder(outDir)
    listing = dir(outDir);
    listing = listing(~ismember({listing.name},{'.','..'}));
    assert(isempty(listing),'pilatus:OutputNotEmpty','Output folder must be new or empty.');
else
    [ok,msg] = mkdir(outDir);
    assert(ok,'pilatus:CreateDirectory','Cannot create output folder: %s',msg);
end

nChunks = ceil(nOutput/opts.ChunkFrames);
firstOutput = (0:nChunks-1)'*opts.ChunkFrames+1;
lastOutput = min(firstOutput+opts.ChunkFrames-1,nOutput);
chunkNames = compose("qphi_%06d.mat",(1:nChunks)');

settings = compactSettings(opts);
manifest.version = 2;
manifest.complete = false;
manifest.files = files(1:nUsed);
manifest.ignoredFiles = files(nUsed+1:end);
manifest.window = window;
manifest.nOutput = nOutput;
manifest.imageSize = imageSize;
manifest.nativeClass = nativeClass;
manifest.settings = settings;
manifest.qCenters = binning.qCenters;
manifest.qEdges = binning.qEdges;
manifest.phiCenters = binning.phiCenters;
manifest.phiEdges = binning.phiEdges;
manifest.chunkNames = chunkNames;
manifest.firstOutput = firstOutput;
manifest.lastOutput = lastOutput;
manifest.definition = 'normalized mean(even-odd), non-overlapping windows';
save(fullfile(outDir,'manifest.mat'),'manifest','-v7','-nocompression');

poolSeconds = 0;
if opts.Workers>1
    tPool = tic;
    p = gcp('nocreate');
    if isempty(p), p = parpool('Processes',opts.Workers); end
    assert(~isa(p,'parallel.ThreadPool'),'pilatus:ThreadPool', ...
        'TIFF I/O requires process workers. Close any thread pool first.');
    assert(p.NumWorkers>=opts.Workers,'pilatus:SmallPool', ...
        'Existing process pool has fewer workers than requested.');
    poolSeconds = toc(tPool);
end

% Partition by contiguous CHUNKS. This keeps source reads contiguous and returns
% only one detector-sized summary per worker instead of one per chunk.
nParts = min(opts.Workers,nChunks);
chunkCuts = floor((0:nParts)*nChunks/nParts);
partMeta = repmat(struct('firstChunk',0,'lastChunk',0,'firstOutput',0,'lastOutput',0, ...
    'firstInput',0,'lastInput',0),nParts,1);
for pidx=1:nParts
    fc = chunkCuts(pidx)+1;
    lc = chunkCuts(pidx+1);
    fo = firstOutput(fc);
    lo = lastOutput(lc);
    partMeta(pidx).firstChunk = fc;
    partMeta(pidx).lastChunk = lc;
    partMeta(pidx).firstOutput = fo;
    partMeta(pidx).lastOutput = lo;
    partMeta(pidx).firstInput = 2*window*(fo-1)+1;
    partMeta(pidx).lastInput = 2*window*lo;
end

if opts.ShowProgress
    fprintf('%d input files -> %d outputs, window=%d, %d chunks, %d worker partition(s).\n', ...
        nUsed,nOutput,window,nChunks,nParts);
    fprintf('Normalization pixels: %d. NormReference=%g.\n',nnz(normBaseMask),opts.NormReference);
    fprintf('q bins=%d',numel(binning.qCenters));
    if ~isempty(binning.phiCenters), fprintf(', phi bins=%d',numel(binning.phiCenters)); end
    fprintf('. SaveQPhi=%d, SaveDiff2D=%d.\n',opts.SaveQPhi,opts.SaveDiff2D);
    fprintf('First normalized difference: [%s] minus [%s].\n',files(2),files(1));
end

partials = cell(nParts,1);
tRun = tic;
if nParts==1
    partials{1} = processPartition(files,outDir,window,imageSize,nativeClass, ...
        opts,normBaseMask,binning,partMeta(1),firstOutput,lastOutput,chunkNames);
else
    nWorkers = opts.Workers;
    parfor (pidx=1:nParts,nWorkers)
        partials{pidx} = processPartition(files,outDir,window,imageSize,nativeClass, ...
            opts,normBaseMask,binning,partMeta(pidx),firstOutput,lastOutput,chunkNames);
    end
end
processingSeconds = toc(tRun);

% Reduce one summary per worker on the client.
sumAll2D = zeros(imageSize,'double');
sumAllRaw2D = zeros(imageSize,'double');
sumAllValidCount = zeros(imageSize,'uint32');
sumDiff2D = zeros(imageSize,'double');
sumDiffValidCount = zeros(imageSize,'uint32');
normValue = nan(nUsed,1);
normValidPixels = zeros(nUsed,1,'uint32');
deltaIq = zeros(numel(binning.qCenters),nOutput,char(opts.OutputClass));
partitionSeconds = zeros(nParts,1);
for pidx=1:nParts
    P = partials{pidx};
    sumAll2D = sumAll2D + P.sumAll2D;
    if opts.SaveRawSum, sumAllRaw2D = sumAllRaw2D + P.sumAllRaw2D; end
    sumAllValidCount = sumAllValidCount + P.sumAllValidCount;
    sumDiff2D = sumDiff2D + P.sumDiff2D;
    sumDiffValidCount = sumDiffValidCount + P.sumDiffValidCount;
    normValue(P.firstInput:P.lastInput) = P.normValue;
    normValidPixels(P.firstInput:P.lastInput) = P.normValidPixels;
    deltaIq(:,P.firstOutput:P.lastOutput) = P.deltaIq;
    partitionSeconds(pidx) = P.seconds;
end
clear partials

% Detector-coordinate summary arrays. Static bad pixels are explicitly NaN.
sumAll2D(sumAllValidCount==0) = NaN;
if opts.SaveRawSum, sumAllRaw2D(sumAllValidCount==0) = NaN; end
avgDiff2D = sumDiff2D ./ double(sumDiffValidCount);
avgDiff2D(sumDiffValidCount==0) = NaN;
if any(badMask,'all')
    sumAll2D(badMask) = NaN;
    if opts.SaveRawSum, sumAllRaw2D(badMask) = NaN; end
    avgDiff2D(badMask) = NaN;
end

% Aggregate reciprocal-space products.
sumAllIq = integrateQ(sumAll2D,binning);
if opts.SaveRawSum, sumAllRawIq = integrateQ(sumAllRaw2D,binning); else, sumAllRawIq = []; end
avgDiffIqFrom2D = integrateQ(avgDiff2D,binning);
meanDeltaIq = mean(deltaIq,2,'omitnan');
if ~isempty(binning.phiCenters)
    sumAllQPhi = integrateQPhi(sumAll2D,binning);
    if opts.SaveRawSum, sumAllRawQPhi = integrateQPhi(sumAllRaw2D,binning); else, sumAllRawQPhi = []; end
    avgDiffQPhiFrom2D = integrateQPhi(avgDiff2D,binning);
else
    sumAllQPhi = [];
    sumAllRawQPhi = [];
    avgDiffQPhiFrom2D = [];
end

normalization.framePosition = (1:nUsed)';
normalization.file = files(1:nUsed);
normalization.value = normValue;
normalization.scale = opts.NormReference ./ normValue;
normalization.validPixels = normValidPixels;
normalization.roiPixelCountAfterStaticMask = uint32(nnz(normBaseMask));

output.firstInputPosition = 2*window*((1:nOutput)'-1)+1;
output.lastInputPosition = 2*window*(1:nOutput)';
output.centerInputPosition = (output.firstInputPosition+output.lastInputPosition)/2;

summary.version = 2;
summary.window = window;
summary.definition = 'mean of normalized even-minus-odd pairs inside each non-overlapping window';
summary.q = binning.qCenters;
summary.qEdges = binning.qEdges;
summary.phi = binning.phiCenters;
summary.phiEdges = binning.phiEdges;
summary.normalization = normalization;
summary.output = output;
summary.deltaIq = deltaIq;
summary.meanDeltaIq = meanDeltaIq;
summary.avgDiff2D = avgDiff2D;
summary.avgDiffIqFrom2D = avgDiffIqFrom2D;
summary.avgDiffQPhiFrom2D = avgDiffQPhiFrom2D;
summary.sumAll2D = sumAll2D;
summary.sumAllValidCount = sumAllValidCount;
summary.sumAllIq = sumAllIq;
summary.sumAllQPhi = sumAllQPhi;
if opts.SaveRawSum
    summary.sumAllRaw2D = sumAllRaw2D;
    summary.sumAllRawIq = sumAllRawIq;
    summary.sumAllRawQPhi = sumAllRawQPhi;
end
summary.settings = settings;

saveStructSafe(fullfile(outDir,'summary.mat'),'summary',summary);

report.processingSeconds = processingSeconds;
report.poolSetupSeconds = poolSeconds;
report.nInputUsed = nUsed;
report.nIgnored = nInput-nUsed;
report.nOutput = nOutput;
report.nChunks = nChunks;
report.nWorkerPartitions = nParts;
report.inputFramesPerSecond = nUsed/processingSeconds;
report.partitionSeconds = partitionSeconds;
report.outputDirectory = outDir;
report.summaryFile = fullfile(outDir,'summary.mat');
manifest.complete = true;
manifest.report = report;
save(fullfile(outDir,'manifest.mat'),'manifest','-v7','-nocompression');

if max(double(normValidPixels))-min(double(normValidPixels))~=0
    warning('pilatus:NormPixelCountChanged', ...
        'Normalization ROI valid-pixel count changed during the run. Inspect summary.normalization.validPixels.');
end
if opts.ShowProgress
    fprintf('Done: %.3f s, %.2f source images/s. Pool setup: %.3f s.\n', ...
        processingSeconds,report.inputFramesPerSecond,poolSeconds);
    fprintf('Main results: %s\n',report.summaryFile);
end
end

function P = processPartition(files,outDir,window,imageSize,nativeClass,opts,normBaseMask,binning,meta,firstOutput,lastOutput,chunkNames)
t = tic;
nLocalOut = meta.lastOutput-meta.firstOutput+1;
nLocalIn = meta.lastInput-meta.firstInput+1;
P.firstOutput = meta.firstOutput;
P.lastOutput = meta.lastOutput;
P.firstInput = meta.firstInput;
P.lastInput = meta.lastInput;
P.sumAll2D = zeros(imageSize,'double');
P.sumAllRaw2D = zeros(imageSize,'double');
P.sumAllValidCount = zeros(imageSize,'uint32');
P.sumDiff2D = zeros(imageSize,'double');
P.sumDiffValidCount = zeros(imageSize,'uint32');
P.normValue = nan(nLocalIn,1);
P.normValidPixels = zeros(nLocalIn,1,'uint32');
P.deltaIq = zeros(numel(binning.qCenters),nLocalOut,char(opts.OutputClass));

for c=meta.firstChunk:meta.lastChunk
    fo = firstOutput(c); lo = lastOutput(c);
    nThis = lo-fo+1;
    deltaIqChunk = zeros(numel(binning.qCenters),nThis,char(opts.OutputClass));
    if opts.SaveQPhi
        deltaQPhi = zeros(numel(binning.qCenters),numel(binning.phiCenters),nThis,char(opts.OutputClass));
    end
    if opts.SaveDiff2D
        diff2D = zeros([imageSize nThis],char(opts.OutputClass));
    end

    for g=fo:lo
        S = zeros(imageSize,char(opts.Accumulator));
        base = 2*window*(g-1);
        for j=1:window
            ia = base+2*j-1;
            ib = base+2*j;

            [A,Araw,nA,nPixA] = normalizedFrame(files(ia),opts.Reader,imageSize,nativeClass, ...
                opts,normBaseMask);
            [P.sumAll2D,P.sumAllRaw2D,P.sumAllValidCount] = ...
                addFrameToSums(P.sumAll2D,P.sumAllRaw2D,P.sumAllValidCount,A,Araw,opts.SaveRawSum);
            la = ia-meta.firstInput+1;
            P.normValue(la)=nA; P.normValidPixels(la)=nPixA;
            clear Araw

            [B,Braw,nB,nPixB] = normalizedFrame(files(ib),opts.Reader,imageSize,nativeClass, ...
                opts,normBaseMask);
            [P.sumAll2D,P.sumAllRaw2D,P.sumAllValidCount] = ...
                addFrameToSums(P.sumAll2D,P.sumAllRaw2D,P.sumAllValidCount,B,Braw,opts.SaveRawSum);
            lb = ib-meta.firstInput+1;
            P.normValue(lb)=nB; P.normValidPixels(lb)=nPixB;
            clear Braw

            % Frames have already been masked and normalized here.
            S = S + (B-A);
            clear A B
        end

        D = S/cast(window,char(opts.Accumulator));
        goodD = isfinite(D);
        Dz = D; Dz(~goodD)=0;
        P.sumDiff2D = P.sumDiff2D + double(Dz);
        P.sumDiffValidCount = P.sumDiffValidCount + uint32(goodD);

        iq = cast(integrateQ(D,binning),char(opts.OutputClass));
        localOut = g-meta.firstOutput+1;
        inChunk = g-fo+1;
        P.deltaIq(:,localOut)=iq;
        deltaIqChunk(:,inChunk)=iq;
        if opts.SaveQPhi
            deltaQPhi(:,:,inChunk)=cast(integrateQPhi(D,binning),char(opts.OutputClass));
        end
        if opts.SaveDiff2D
            diff2D(:,:,inChunk)=cast(D,char(opts.OutputClass));
        end
    end

    if opts.SaveQPhi || opts.SaveDiff2D
        chunkMeta.firstOutput = fo;
        chunkMeta.lastOutput = lo;
        chunkMeta.firstInput = 2*window*(fo-1)+1;
        chunkMeta.lastInput = 2*window*lo;
        outfile = fullfile(outDir,chunkNames(c));
        tmp = outfile+".partial.mat";
        if opts.SaveQPhi && opts.SaveDiff2D
            save(tmp,'deltaIqChunk','deltaQPhi','diff2D','chunkMeta','-v7','-nocompression');
        elseif opts.SaveQPhi
            save(tmp,'deltaIqChunk','deltaQPhi','chunkMeta','-v7','-nocompression');
        else
            save(tmp,'deltaIqChunk','diff2D','chunkMeta','-v7','-nocompression');
        end
        [ok,msg] = movefile(tmp,outfile);
        assert(ok,'pilatus:RenameOutput','Cannot finalize output chunk: %s',msg);
    end
end
P.seconds = toc(t);
end

function [xNorm,xRaw,normValue,normValidPixels] = normalizedFrame(filename,reader,imageSize,nativeClass,opts,normBaseMask)
raw = pilatus_read_tiff(filename,reader);
assert(isequal(size(raw),imageSize),'pilatus:ImageSize','Image dimensions changed within a run.');
assert(strcmp(class(raw),nativeClass),'pilatus:ImageType','Image datatype changed within a run.');

xRaw = cast(raw,char(opts.Accumulator));
good = true(imageSize);
if ~isempty(opts.BadMask), good = good & ~opts.BadMask; end
if opts.MaskNegative, good = good & ~(raw<0); end
for value=reshape(opts.BadValues,1,[])
    good = good & ~(raw==value);  % compare in native datatype before cast precision can matter
end
if isfloat(raw), good = good & isfinite(raw); end
xRaw(~good)=NaN;

normGood = normBaseMask & good;
normValidPixels = uint32(nnz(normGood));
assert(normValidPixels>0,'pilatus:NoNormPixels','No valid normalization pixels in %s.',filename);
normValue = sum(double(xRaw(normGood)),'omitnan');
assert(isfinite(normValue) && normValue>0,'pilatus:BadNormalization', ...
    'Normalization sum is non-positive/nonfinite in %s.',filename);

xNorm = xRaw * cast(opts.NormReference/normValue,char(opts.Accumulator));
end

function [sumNorm,sumRaw,count] = addFrameToSums(sumNorm,sumRaw,count,xNorm,xRaw,saveRaw)
good = isfinite(xNorm);
t = xNorm; t(~good)=0;
sumNorm = sumNorm + double(t);
count = count + uint32(good);
if saveRaw
    r = xRaw; r(~good)=0;
    sumRaw = sumRaw + double(r);
end
end

function B = buildBinning(qMap,phiMap,badMask,opts)
qMap = double(qMap);
base = ~badMask & isfinite(qMap);
if isempty(opts.QEdges)
    qv = qMap(base);
    assert(~isempty(qv),'pilatus:NoQPixels','No finite unmasked q-map pixels.');
    qMin=min(qv); qMax=max(qv);
    assert(qMax>qMin,'pilatus:QRange','QMap must span a nonzero range.');
    qEdges=linspace(qMin,qMax,opts.NQBins+1);
else
    qEdges=reshape(double(opts.QEdges),1,[]);
    assert(numel(qEdges)>=2 && all(isfinite(qEdges)) && all(diff(qEdges)>0), ...
        'pilatus:QEdges','QEdges must be finite and strictly increasing.');
end
qBin = discretize(qMap,qEdges);
base = base & isfinite(qBin);

if isempty(opts.Geometry), geometry = ones(size(qMap)); else, geometry=double(opts.Geometry); end
if isempty(opts.Polarization), polarization = ones(size(qMap)); else, polarization=double(opts.Polarization); end
factor = geometry.*polarization;
switch opts.CorrectionMode
    case "divide"
        base = base & isfinite(factor) & factor~=0;
    case "multiply"
        base = base & isfinite(factor);
    case "none"
        factor = ones(size(qMap));
end

pix = find(base);
assert(~isempty(pix),'pilatus:NoIntegrationPixels','No pixels remain for q integration.');
qID = double(qBin(pix));
nQ = numel(qEdges)-1;
B.Bq = sparse(qID,1:numel(pix),1,nQ,numel(pix));
B.qStaticCount = full(sum(B.Bq,2));
B.pixelIndex = pix;
B.qEdges = qEdges;
B.qCenters = (qEdges(1:end-1)+qEdges(2:end))/2;

switch opts.CorrectionMode
    case "divide", B.correction = 1./factor(pix);
    case "multiply", B.correction = factor(pix);
    case "none", B.correction = ones(numel(pix),1);
end
B.correction = reshape(double(B.correction),[],1);

B.Bqp = [];
B.qpStaticCount = [];
B.phiEdges = [];
B.phiCenters = [];
if ~isempty(phiMap)
    phiMap=double(phiMap);
    if isempty(opts.PhiEdges)
        phiv=phiMap(base & isfinite(phiMap));
        assert(~isempty(phiv),'pilatus:NoPhiPixels','No finite phi pixels remain.');
        pMin=min(phiv); pMax=max(phiv);
        assert(pMax>pMin,'pilatus:PhiRange','PhiMap must span a nonzero range.');
        phiEdges=linspace(pMin,pMax,opts.NPhiBins+1);
    else
        phiEdges=reshape(double(opts.PhiEdges),1,[]);
        assert(numel(phiEdges)>=2 && all(isfinite(phiEdges)) && all(diff(phiEdges)>0), ...
            'pilatus:PhiEdges','PhiEdges must be finite and strictly increasing.');
    end
    phiBin=discretize(phiMap,phiEdges);
    phiID=double(phiBin(pix));
    goodPhi=isfinite(phiID);

    % q-only integration may use pixels without a valid phi value. For q-phi,
    % make a compact second pixel subset and a mapping into the q-pixel vector.
    B.qpToQPixel = find(goodPhi);
    qIDqp=qID(goodPhi);
    phiID=phiID(goodPhi);
    nPhi=numel(phiEdges)-1;
    flatID=qIDqp + (phiID-1)*nQ; % reshape later as [q,phi]
    B.Bqp=sparse(flatID,1:numel(flatID),1,nQ*nPhi,numel(flatID));
    B.qpStaticCount=full(sum(B.Bqp,2));
    B.phiEdges=phiEdges;
    B.phiCenters=(phiEdges(1:end-1)+phiEdges(2:end))/2;
end
end

function iq = integrateQ(image,B)
v = double(image(B.pixelIndex)).*B.correction;
good=isfinite(v);
if all(good)
    num=B.Bq*v;
    den=B.qStaticCount;
else
    v(~good)=0;
    num=B.Bq*v;
    den=B.Bq*double(good);
end
iq=num./den;
iq(den==0)=NaN;
end

function qphi = integrateQPhi(image,B)
assert(~isempty(B.Bqp),'pilatus:NoPhiBinning','PhiMap/PhiEdges were not configured.');
vQ = double(image(B.pixelIndex)).*B.correction;
v = vQ(B.qpToQPixel);
good=isfinite(v);
if all(good)
    num=B.Bqp*v;
    den=B.qpStaticCount;
else
    v(~good)=0;
    num=B.Bqp*v;
    den=B.Bqp*double(good);
end
z=num./den;
z(den==0)=NaN;
qphi=reshape(z,numel(B.qCenters),numel(B.phiCenters));
end

function validateDetectorArray(A,imageSize,name)
assert(isequal(size(A),imageSize),'pilatus:ArraySize','%s must match detector size [%d %d].', ...
    name,imageSize(1),imageSize(2));
end

function settings = compactSettings(opts)
settings = opts;
% Do not duplicate detector-sized calibration maps inside every manifest/summary.
settings.QMap = sprintf('[detector-sized %s]',class(opts.QMap));
if isempty(opts.PhiMap), settings.PhiMap='[]'; else, settings.PhiMap=sprintf('[detector-sized %s]',class(opts.PhiMap)); end
if isempty(opts.Geometry), settings.Geometry='[] -> ones'; else, settings.Geometry=sprintf('[detector-sized %s]',class(opts.Geometry)); end
if isempty(opts.Polarization), settings.Polarization='[] -> ones'; else, settings.Polarization=sprintf('[detector-sized %s]',class(opts.Polarization)); end
settings.NormMask = sprintf('[logical %dx%d, %d true]',size(opts.NormMask,1),size(opts.NormMask,2),nnz(opts.NormMask));
if isempty(opts.BadMask), settings.BadMask='[]'; else, settings.BadMask=sprintf('[logical %dx%d, %d true]',size(opts.BadMask,1),size(opts.BadMask,2),nnz(opts.BadMask)); end
end

function saveStructSafe(filename,varName,S)
% summary.deltaIq can exceed the v7 single-variable limit for very long runs.
tmp = filename+".partial.mat";
bytes = estimateStructBytes(S);
if bytes<1.5e9
    eval([varName ' = S;']); %#ok<EVLDIR>
    save(tmp,varName,'-v7','-nocompression');
else
    eval([varName ' = S;']); %#ok<EVLDIR>
    save(tmp,varName,'-v7.3','-nocompression');
end
[ok,msg]=movefile(tmp,filename);
assert(ok,'pilatus:RenameSummary','Cannot finalize summary file: %s',msg);
end

function n = estimateStructBytes(S)
% Conservative estimate for the large numeric fields; metadata overhead is tiny
% relative to the threshold and is intentionally ignored.
n=0;
f=fieldnames(S);
for k=1:numel(f)
    v=S.(f{k});
    if isnumeric(v) || islogical(v)
        w=whos('v'); n=n+w.bytes;
    elseif isstruct(v)
        n=n+estimateStructBytes(v);
    end
end
end
