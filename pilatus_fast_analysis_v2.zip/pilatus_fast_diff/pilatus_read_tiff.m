function A = pilatus_read_tiff(filename,reader)
%PILATUS_READ_TIFF Read page 1 without orientation changes or normalization.
arguments
    filename (1,1) string
    reader (1,1) string {mustBeMember(reader,["tiff","imread"])} = "tiff"
end
if reader=="imread"
    A = imread(filename,'tif');
else
    t = Tiff(char(filename),'r');
    try
        A = read(t);
    catch err
        close(t);
        rethrow(err);
    end
    close(t);
end
end
